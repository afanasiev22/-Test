package pom;

import core.BaseClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPagePom extends BaseClass {

    WebDriver driver;
    public RegistrationPagePom(WebDriver driver)
    {
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }
    @FindBy(xpath = "//button[text()='Înregistrare']")
      public   WebElement registerBtn;

    @FindBy(xpath = "//input[@name='email']")
    public WebElement emailField;

    @FindBy(xpath = "//input[@name='login']")
    public WebElement loginField;

    @FindBy(xpath = "//input[@name='password']")
    public  WebElement passwordField;

    @FindBy(xpath = "//input[@id='agree-rules']")
    public WebElement captcha_agree_rules;


}