package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class StartPagePom {
    WebDriver driver;

    public StartPagePom(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver,this);

    }
    @FindBy(xpath = "//iframe[@id= 'topbar-panel']")
    public WebElement lagBarFrame;

    @FindBy(xpath = "//li[@id='user-language']")
   public WebElement languageBar;

    @FindBy(xpath = "//li[@id= 'user-language']//button[text()= 'română']")
    public WebElement romanianLang;

 @FindBy(xpath = "//li[@id= 'user-language']//button[text()= 'русский']")
 public WebElement russianLang;

    @FindBy(xpath = "//a[text()= 'Transport']")
    public WebElement Transport;

    @FindBy(xpath = "//a[text()= 'Imobiliare']")
    public WebElement Imobiliare;

    @FindBy(xpath = "//a[text()= 'Aparate telefonice și gadget-uri']")
    public WebElement TelefoaneSiGadgeturi;

    @FindBy(xpath = "//a[text()= 'Calculatoare și birotică']")
    public WebElement CalculatoareSiBirotica;

    @FindBy(xpath = "//a[text()= 'Construcții și reparații']")
    public WebElement ConstructiiSiReparatii;

    @FindBy(xpath = "//a[text()= 'Haine, încălțăminte și accesorii']")
    public WebElement HaineIncaltamine;

    @FindBy(xpath = "//a[text()= 'Mobilă și interior']")
    public WebElement MobilaInterior;

    @FindBy(xpath = "//a[text()= 'Audio-Video-Foto']")
    public WebElement AudioVideoFoto;

    @FindBy(xpath = "//a[text()= 'Diverse']")
    public WebElement Diverse;

    @FindBy(xpath = "//a[text()= 'Totul pentru sărbători']")
    public WebElement TotulPentruSarbatori;

    @FindBy(xpath = "//a[text()= 'Tehnică de uz casnic']")
    public WebElement TehnicaUzCasnic;

    @FindBy(xpath = "//a[text()= 'Oferte de lucru']")
    public WebElement OferteDeLucru;

    @FindBy(xpath = "//a[text()= 'Servicii']")
    public WebElement Servicii;

    @FindBy(xpath = "//a[text()= 'Sport, sănătate, frumusețe']")
    public WebElement SportSanatateFrumusete;

    @FindBy(xpath = "//a[text()= 'Turism, recreație și divertisment']")
    public WebElement TurismRecreatieDivertisment;

    @FindBy(xpath = "//nav/ul/li/a[text()= 'Business']")
    public WebElement Business;

    @FindBy(xpath = "//a[text()= 'Totul pentru casă și oficiu']")
    public WebElement TotulPentruCasa;

    @FindBy(xpath = "//a[text()= 'Lumea copiilor']")
    public WebElement LumeaCopiilor;

    @FindBy(xpath = "//a[text()= 'Gospodăria țărănească']")
    public WebElement GospodariaTaraneasca;

    @FindBy(xpath = "//a[text()= '//a[text()= 'Animale de companie și plante']")
    public WebElement AnimaleDeCompanie;

    @FindBy(xpath = "//a[text()= 'Instrumente muzicale']")
    public WebElement InstrumenteMuzicale;

    @FindBy(xpath = "//a[text()= 'Matrimoniale']")
    public WebElement Matrimoniale;

    @FindBy(xpath = "//nav/ul/li/a[text()= 'înregistrare']")
    public WebElement inregistrareButonJos;

    @FindBy(xpath = "//a[text()= 'autentificare']")
    public WebElement autentificare;

    @FindBy(xpath = "//div/ul/li/a[text()= 'înregistrare']")
    public WebElement inregistrareButonSus;

    @FindBy(xpath = "//div/button[text()= 'Categorii']")
    public WebElement CategoriiButon;

    @FindBy(xpath = "//a[text()= 'intră']")
    public WebElement intra;

    @FindBy(xpath = "//input[@id= 'js-search-input']")
    public WebElement CautareInAnunturi;

    @FindBy(xpath = "//span[text()= 'Caută']")
    public WebElement CautaButton;










}
