package core;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ReadConfig  {
    Properties properties;
    public ReadConfig()  {
        try {
            File file = new File("src/main/resources/app.propreties");
            FileInputStream fileInputStream = new FileInputStream(file);
            properties = new Properties();
            properties.load(fileInputStream);
        }catch (Exception e){
            System.out.println(e);
        }

    }


    public String getConfigValue(String key) {
        String value = properties.getProperty(key);
        return value;
    }

}
