package core;

import jdk.jshell.execution.Util;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.internal.BaseClassFinder;
import pom.RegistrationPagePom;
import pom.StartPagePom;
import utils.Utilss;

public class BaseClass {
    ReadConfig readConfig = new ReadConfig();
    ChromeDriver driver;
    public StartPagePom startPagePom;
    public Utilss utils;
    public RegistrationPagePom registrationPagePom;

    @BeforeClass
    public void initDriver() {
        System.out.println("Hello");
        System.setProperty("webdriver.chrome.driver", readConfig.getConfigValue("chromeDriver"));
        driver = new ChromeDriver();


    }
    @BeforeMethod
    public void createObject() {

        startPagePom = new StartPagePom(driver);
        utils=new Utilss(driver);
        registrationPagePom=new RegistrationPagePom(driver);
   //     utils.ecplicitMethodToBeClikleable(15, startPagePom.languageBar);
    }



    @BeforeMethod
    public void printhSomth() {
        System.out.println("test method");
    }



    @BeforeMethod
    public void starTesting() throws InterruptedException {
        driver.manage().window().maximize();
        startingPage("roUrl");

//        driver.switchTo().frame(1);
//        utils.ecplicitMethodToBeClikleable(15, startPagePom.languageBar);
//        choiseLang("ro");
//        Thread.sleep(10000);


    }

    @AfterClass
    public void godbye() {
        driver.close();
        System.out.println("Goodbye");
    }


    public void startingPage(String lang) {
        switch (lang) {
            case ("roUrl"):
                driver.get(readConfig.getConfigValue(lang));
                utils.ecplicitMethodToBeDisplayed(15,startPagePom.inregistrareButonJos);
                break;
            case ("ruUrl"):
                driver.get(readConfig.getConfigValue(lang));
                break;

        }

    }
    public void choiseLang(String lang){
        switch (lang){
            case "ro":
                utils.JVSClick(startPagePom.inregistrareButonJos);
                utils.JVSClick(startPagePom.romanianLang);
                break;
            case "ru":
                utils.JVSClick(startPagePom.languageBar);
                utils.JVSClick(startPagePom.russianLang);
        }



    }



}