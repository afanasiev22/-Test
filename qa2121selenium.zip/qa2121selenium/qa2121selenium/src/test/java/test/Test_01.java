package test;

import core.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v85.input.Input;
import org.testng.annotations.Test;

import javax.swing.*;
import java.io.Writer;

public class Test_01 extends BaseClass {
    @Test
    public void registerTest() throws InterruptedException {
        utils.JVSClick(startPagePom.inregistrareButonJos);
        utils.ecplicitMethodToBeDisplayed(15,registrationPagePom.registerBtn);
        registrationPagePom.emailField.sendKeys("dfassd15g@mail.ru");
        registrationPagePom.passwordField.sendKeys("15fgda!");
        registrationPagePom.loginField.sendKeys("gfdasdfhf");
        registrationPagePom.captcha_agree_rules.click();
        registrationPagePom.registerBtn.click();
        System.out.println("Stop");

//startPagePom.languageBar.click();
//startPagePom.romanianLang.click();
//startPagePom.Transport.click();
 // startPagePom.TehnicaUzCasnic.click();







    }
}