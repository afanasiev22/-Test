package utils;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Utilss {
    public WebDriver driver;

    public Utilss(WebDriver driver) {
        this.driver = driver;
    }

    public void ecplicitMethodToBeDisplayed(int seconds, WebElement element) {
        (new WebDriverWait(driver, Duration.ofSeconds(seconds))).until(ExpectedConditions.visibilityOf(element));

    }

    public void ecplicitMethodToBeClikleable(int seconds, WebElement element) {
        (new WebDriverWait(driver, Duration.ofSeconds(seconds)))
                .until(ExpectedConditions.elementToBeClickable(element));

    }
    public void JVSClick(WebElement element){
        JavascriptExecutor executor=(JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();",element);
    }
}
